package com.bandclick.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** BandClick prototype: classic Bluetooth carries control messages; each phone makes its own click. */
public class MainActivity extends Activity {
    private static final UUID APP_UUID = UUID.fromString("a6f5c2e1-91a0-4b65-9a70-42414e434c4b");
    private static final int REQ_BT = 77;
    private static final int REQ_ENABLE_BT = 78;
    private BluetoothAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Peer> peers = new CopyOnWriteArrayList<>();
    private final List<String> peerNames = new ArrayList<>();
    private ArrayAdapter<String> peerAdapter;
    private Spinner deviceSpinner;
    private EditText usernameInput, roomInput, bpmInput;
    private TextView status, roomLabel, roleLabel, bpmLabel, membersLabel, beatLabel;
    private Button startButton, stopButton, hostButton, joinButton, refreshButton, tapButton;
    private volatile boolean isHost = false, playing = false;
    private volatile int bpm = 120;
    private String username = "", roomCode = "";
    private ServerThread server;
    private ScheduledExecutorService metronome;
    private long nextTap = 0;
    private int tapCount = 0;
    private ToneGenerator tone;
    private volatile long beatNumber = 0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        adapter = BluetoothAdapter.getDefaultAdapter();
        tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 90);
        buildUi();
        requestBluetoothPermissions();
        if (adapter == null) { setStatus("This phone does not support Bluetooth."); disableControls(); }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(18), dp(20), dp(24)); root.setBackgroundColor(0xFFF7F4FF);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("BandClick", 30, true); title.setGravity(Gravity.CENTER); root.addView(title, matchWrap());
        TextView subtitle = text("One room. One tempo. Every member.", 14, false); subtitle.setGravity(Gravity.CENTER); root.addView(subtitle, matchWrap());
        root.addView(gap(18));
        usernameInput = edit("Your username (required)"); root.addView(usernameInput, matchWrap());
        roomInput = edit("Room code (for joining)"); root.addView(roomInput, matchWrap());
        hostButton = button("HOST A ROOM"); root.addView(hostButton, matchWrap());
        joinButton = button("JOIN ROOM"); root.addView(joinButton, matchWrap());
        roomLabel = text("Room: —", 18, true); root.addView(roomLabel, matchWrap());
        roleLabel = text("Not connected", 14, false); root.addView(roleLabel, matchWrap());
        root.addView(gap(8));
        TextView deviceLabel = text("Paired Bluetooth phones", 15, true); root.addView(deviceLabel, matchWrap());
        deviceSpinner = new Spinner(this); peerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, peerNames); deviceSpinner.setAdapter(peerAdapter); root.addView(deviceSpinner, matchWrap());
        refreshButton = button("REFRESH PAIRED PHONES"); root.addView(refreshButton, matchWrap());
        root.addView(gap(10));
        bpmLabel = text("120 BPM", 36, true); bpmLabel.setGravity(Gravity.CENTER); root.addView(bpmLabel, matchWrap());
        bpmInput = edit("BPM (40–240)"); bpmInput.setText("120"); root.addView(bpmInput, matchWrap());
        Button apply = button("SET BPM"); root.addView(apply, matchWrap());
        tapButton = button("TAP TEMPO"); root.addView(tapButton, matchWrap());
        beatLabel = text("●  READY", 18, true); beatLabel.setGravity(Gravity.CENTER); root.addView(beatLabel, matchWrap());
        startButton = button("START METRONOME"); root.addView(startButton, matchWrap());
        stopButton = button("STOP METRONOME"); root.addView(stopButton, matchWrap());
        membersLabel = text("Members: 0", 14, false); root.addView(membersLabel, matchWrap());
        status = text("Pair phones in Android Bluetooth settings first. No internet or Wi-Fi is used for the session.", 13, false); root.addView(status, matchWrap());

        hostButton.setOnClickListener(v -> hostRoom());
        joinButton.setOnClickListener(v -> joinRoom());
        refreshButton.setOnClickListener(v -> refreshPairedDevices());
        apply.setOnClickListener(v -> applyBpmFromInput());
        tapButton.setOnClickListener(v -> tapTempo());
        startButton.setOnClickListener(v -> startMetronome());
        stopButton.setOnClickListener(v -> stopMetronome());
        refreshPairedDevices(); updatePermissionsUi();
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }
    @Override public void onRequestPermissionsResult(int req, String[] p, int[] g) {
        super.onRequestPermissionsResult(req, p, g);
        if (req == REQ_BT) {
            boolean connectGranted = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
            refreshPairedDevices();
            updatePermissionsUi();
            if (connectGranted) promptEnableBluetoothIfNeeded();
            else setStatus("Bluetooth permission is required. Allow Nearby devices, then try again.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ENABLE_BT) {
            if (adapter != null && adapter.isEnabled()) {
                setStatus("Bluetooth is on. Pair the band phones in Android Bluetooth settings, then refresh paired phones.");
                refreshPairedDevices();
            } else {
                setStatus("Bluetooth is off. Turn it on to host or join a BandClick room.");
                toast("Bluetooth must be on to use BandClick.");
            }
        }
    }

    private void updatePermissionsUi() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            setStatus("Allow Nearby devices/Bluetooth permission to use BandClick.");
        } else if (adapter != null && !adapter.isEnabled()) {
            setStatus("Bluetooth is off. Turn it on to host or join a room.");
        }
    }

    private boolean promptEnableBluetoothIfNeeded() {
        if (adapter == null) {
            setStatus("This phone does not support Bluetooth.");
            return false;
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissions();
            return false;
        }
        try {
            if (!adapter.isEnabled()) {
                setStatus("Please enable Bluetooth to continue.");
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableIntent, REQ_ENABLE_BT);
                return false;
            }
            return true;
        } catch (SecurityException e) {
            setStatus("Bluetooth permission is required.");
            return false;
        }
    }

    private void hostRoom() {
        if (!checkBtReady()) return;
        username = usernameInput.getText().toString().trim();
        if (username.isEmpty()) { toast("Enter a username first."); return; }
        isHost = true; roomCode = String.format(Locale.US, "%04d", new Random().nextInt(10000));
        roomLabel.setText("Room code: " + roomCode); roleLabel.setText("Host: " + username + " (controls BPM/start/stop)");
        bpmInput.setEnabled(true); startButton.setEnabled(true); stopButton.setEnabled(true); tapButton.setEnabled(true);
        server = new ServerThread(); server.start();
        setStatus("Room open. Pair members in Android Bluetooth settings, then share code " + roomCode + ". Keep this app open.");
        updateMembers();
    }

    private void joinRoom() {
        if (!checkBtReady()) return;
        username = usernameInput.getText().toString().trim(); roomCode = roomInput.getText().toString().trim();
        if (username.isEmpty()) { toast("Enter a username first."); return; }
        if (roomCode.length() != 4) { toast("Enter the 4-digit room code."); return; }
        if (peerNames.isEmpty()) { refreshPairedDevices(); toast("Pair with the host in Android Bluetooth settings, then select the host phone."); return; }
        int pos = deviceSpinner.getSelectedItemPosition();
        Set<BluetoothDevice> bonded;
        try { bonded = adapter.getBondedDevices(); } catch (SecurityException e) { toast("Bluetooth permission is required."); return; }
        if (pos < 0 || pos >= peerNames.size()) { toast("Select the host phone first."); return; }
        List<BluetoothDevice> list = new ArrayList<>();
        for (BluetoothDevice d : bonded) { String n = safeName(d); if ((n + " (" + safeAddress(d) + ")").equals(peerNames.get(pos))) list.add(d); }
        if (list.isEmpty()) { toast("Host not found in paired devices."); return; }
        isHost = false; roleLabel.setText("Member: " + username + " (listen only)"); roomLabel.setText("Joining room " + roomCode + "…");
        bpmInput.setEnabled(false); startButton.setEnabled(false); stopButton.setEnabled(false); tapButton.setEnabled(false);
        new ClientThread(list.get(0), roomCode, username).start();
    }

    private boolean checkBtReady() {
        if (adapter == null) { toast("Bluetooth is not supported."); return false; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissions();
            toast("Allow Nearby devices permission first.");
            return false;
        }
        return promptEnableBluetoothIfNeeded();
    }
    private void refreshPairedDevices() {
        peerNames.clear();
        if (adapter != null && (Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)) {
            try { Set<BluetoothDevice> ds = adapter.getBondedDevices(); for (BluetoothDevice d : ds) peerNames.add(safeName(d) + " (" + safeAddress(d) + ")"); } catch (SecurityException ignored) { }
        }
        if (peerAdapter != null) peerAdapter.notifyDataSetChanged();
        setStatus("Found " + peerNames.size() + " paired device(s). Pair phones using Android Bluetooth settings first.");
    }

    private class ServerThread extends Thread {
        private BluetoothServerSocket serverSocket;
        @Override public void run() {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord("BandClick", APP_UUID);
                while (!isInterrupted() && isHost) {
                    BluetoothSocket socket = serverSocket.accept();
                    if (socket != null) new PeerThread(socket, true).start();
                }
            } catch (IOException | SecurityException e) { ui.post(() -> setStatus("Bluetooth host stopped: " + e.getMessage())); }
        }
        void closeServer() { try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {} interrupt(); }
    }

    private class ClientThread extends Thread {
        private final BluetoothDevice device; private final String code, name;
        ClientThread(BluetoothDevice d, String c, String n) { device=d; code=c; name=n; }
        @Override public void run() {
            BluetoothSocket socket = null;
            try {
                socket = device.createRfcommSocketToServiceRecord(APP_UUID); socket.connect();
                Peer p = new Peer(socket, false); peers.add(p); p.start(); p.send("JOIN|" + code + "|" + clean(name));
                ui.post(() -> { roomLabel.setText("Room: " + code); setStatus("Connected to host. Waiting for room approval/state."); });
            } catch (IOException | SecurityException e) { if(socket!=null) try{socket.close();}catch(IOException ignored){} ui.post(() -> setStatus("Could not connect. Check pairing, select the host phone, and ensure its room is open.")); }
        }
    }

    private class PeerThread extends Thread {
        private final BluetoothSocket socket; private final boolean serverSide;
        PeerThread(BluetoothSocket s, boolean ss) { socket=s; serverSide=ss; }
        @Override public void run() {
            Peer p = new Peer(socket, serverSide); peers.add(p); p.start();
        }
    }

    private class Peer extends Thread {
        final BluetoothSocket socket; final boolean hostSide; volatile PrintWriter out;
        private final List<String> pending = new ArrayList<>();
        Peer(BluetoothSocket s, boolean h) { socket=s; hostSide=h; }
        synchronized void send(String msg) {
            try {
                if (out != null) { out.println(msg); out.flush(); }
                else pending.add(msg);
            } catch(Exception ignored) {}
        }
        @Override public void run() {
            try {
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
                synchronized (this) { for (String msg : pending) out.println(msg); pending.clear(); out.flush(); }
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                String line;
                while ((line=in.readLine())!=null) handleMessage(this,line);
            } catch (IOException | SecurityException ignored) { }
            finally { peers.remove(this); try{socket.close();}catch(IOException ignored){} ui.post(() -> updateMembers()); }
        }
    }

    private void handleMessage(Peer peer, String msg) {
        String[] a = msg.split("\\|", -1); if(a.length==0) return;
        if (isHost && a[0].equals("JOIN") && a.length>=3) {
            boolean valid = a[1].equals(roomCode);
            peer.send(valid ? "STATE|"+bpm+"|"+(playing?"1":"0")+"|"+System.currentTimeMillis()+"|"+clean(username) : "REJECT");
            ui.post(() -> { setStatus(valid ? "Member requested/connected: " + a[2] : "A device tried an incorrect room code."); updateMembers(); });
            return;
        }
        if (!isHost && a[0].equals("STATE") && a.length>=4) {
            try { bpm = Integer.parseInt(a[1]); playing = a[2].equals("1"); long hostStart=Long.parseLong(a[3]); updateBpmUi(); if(playing) scheduleStart(Math.max(0, hostStart-System.currentTimeMillis())); else cancelLocal(); ui.post(() -> { roomLabel.setText("Room: " + roomCode); setStatus("Connected to host. Listening only."); }); } catch(Exception ignored){}
        } else if (!isHost && a[0].equals("BPM") && a.length>=2) { try{bpm=Integer.parseInt(a[1]); updateBpmUi();}catch(Exception ignored){} }
        else if (!isHost && a[0].equals("START") && a.length>=2) { try { long t=Long.parseLong(a[1]); playing=true; scheduleStart(Math.max(0,t-System.currentTimeMillis())); }catch(Exception ignored){} }
        else if (!isHost && a[0].equals("STOP")) { playing=false; cancelLocal(); }
        else if (a[0].equals("REJECT")) ui.post(() -> setStatus("Wrong room code. Ask the host for the current code."));
    }

    private void applyBpmFromInput() {
        if (!isHost) { toast("Only the host can change BPM."); return; }
        try { int v=Integer.parseInt(bpmInput.getText().toString().trim()); if(v<40||v>240) throw new NumberFormatException(); bpm=v; updateBpmUi(); broadcast("BPM|"+bpm); setStatus("BPM set to "+bpm+"."); }
        catch(NumberFormatException e) { toast("Enter a BPM between 40 and 240."); }
    }
    private void tapTempo() {
        if (!isHost) { toast("Only the host can set tempo."); return; }
        long now=System.currentTimeMillis();
        if(nextTap==0 || now-nextTap>2000) { tapCount=1; } else { tapCount++; long interval=(now-nextTap); int newBpm=(int)Math.round(60000.0/interval); if(newBpm>=40&&newBpm<=240) { bpm=newBpm; bpmInput.setText(String.valueOf(bpm)); updateBpmUi(); broadcast("BPM|"+bpm); } }
        nextTap=now; setStatus("Tap tempo: tap steadily several times.");
    }
    private void startMetronome() {
        if (!isHost) { toast("Only the host can start the metronome."); return; }
        try { bpm=Integer.parseInt(bpmInput.getText().toString().trim()); } catch(Exception ignored){}
        if(bpm<40||bpm>240) { toast("BPM must be 40–240."); return; }
        playing=true; long startAt=System.currentTimeMillis()+1800; broadcast("START|"+startAt); scheduleStart(Math.max(0,startAt-System.currentTimeMillis())); setStatus("Metronome running at "+bpm+" BPM.");
    }
    private void stopMetronome() { if(!isHost) return; playing=false; broadcast("STOP"); cancelLocal(); setStatus("Metronome stopped."); }
    private void broadcast(String msg) { for(Peer p:peers) p.send(msg); }
    private synchronized void scheduleStart(long delayMs) {
        cancelLocal();
        if(metronome!=null) metronome.shutdownNow();
        metronome=Executors.newSingleThreadScheduledExecutor();
        metronome.scheduleAtFixedRate(() -> { if(!playing)return; long n=beatNumber++; try { tone.startTone(n%4==0?ToneGenerator.TONE_PROP_BEEP2:ToneGenerator.TONE_PROP_BEEP, 55); } catch(Exception ignored){} ui.post(() -> { beatLabel.setText((n%4==0?"●":"○")+"  PLAYING"); }); }, delayMs, Math.max(1,60000/bpm), TimeUnit.MILLISECONDS);
    }
    private synchronized void cancelLocal() { if(metronome!=null) { metronome.shutdownNow(); metronome=null; } ui.post(() -> beatLabel.setText("●  STOPPED")); }
    private void updateBpmUi() { ui.post(() -> bpmLabel.setText(bpm+" BPM")); }
    private void updateMembers() { ui.post(() -> membersLabel.setText("Connected devices: "+peers.size())); }
    private void disableControls() { hostButton.setEnabled(false); joinButton.setEnabled(false); }
    private void setStatus(String s) { if(status!=null) status.setText(s); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    private String clean(String s) { return s.replace("|"," ").replace("\n"," ").trim(); }
    private String safeName(BluetoothDevice d) { try { String n=d.getName(); return n==null?"Bluetooth device":n; }catch(SecurityException e){return "Bluetooth device";} }
    private String safeAddress(BluetoothDevice d) { try{return d.getAddress();}catch(SecurityException e){return "address hidden";} }
    private TextView text(String s,int size,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF201A2C); if(bold)t.setTypeface(null,1); t.setPadding(0,dp(7),0,dp(7)); return t; }
    private EditText edit(String hint) { EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextSize(16); e.setPadding(dp(12),dp(8),dp(12),dp(8)); return e; }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    private View gap(int h) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }

    @Override protected void onDestroy() { super.onDestroy(); playing=false; cancelLocal(); if(server!=null)server.closeServer(); for(Peer p:peers){try{p.socket.close();}catch(Exception ignored){}} if(tone!=null)tone.release(); }
}
