# BandClick — phone-first prototype

BandClick is an experimental Android app for a shared metronome over Bluetooth Classic RFCOMM. The host controls BPM/start/stop; members enter a username and room code and listen to locally generated clicks. The room code is an application-level check, not Bluetooth discovery. Phones must first be paired in Android settings, and a member chooses the host from paired devices.

## Build without a PC

This project is configured for a cloud build through GitHub Actions:

1. On your phone, create a GitHub account/repository and upload the *contents* of this folder to the repository root (including `.github/workflows/build-apk.yml`).
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Choose **Build BandClick APK** → **Run workflow**.
4. When the run succeeds, open it and download the `BandClick-debug-apk` artifact. Extract the artifact ZIP and install `app-debug.apk`.

The workflow uses free GitHub Actions minutes within account limits. No personal access token is needed if you upload files through GitHub's website while signed in.

## Important prototype limitations

- This source has not been compiled or validated on physical devices. Treat it as an experimental starting point, not a release-ready app.
- Bluetooth Classic RFCOMM is used for control messages, not audio streaming. Each phone generates its own click using Android ToneGenerator.
- The current prototype sends a start timestamp using wall-clock time and assumes devices' clocks are reasonably aligned. It does not implement robust clock-offset estimation, drift correction, reconnection, or per-earbud latency calibration. It cannot promise synchronized clicks for live performance.
- Room code is checked after the Bluetooth connection is established. Phones must be paired in Android Bluetooth settings; joiners select the host from their paired-device list.
- Keep the app open during a session. Background execution and Bluetooth permission behavior vary by Android version.
